function outer(){
    var a= {Car:"Toyota Camry"};
    var b= {Color:"blue"};
    console.log(a,b);

    function inner(a,b){ 
    var a= {Car:"Honda"};
    var b= {Color:"white"};
    console.log(a,b);
    }

    inner(a,b);{
    var b= {Color:"pink"};
    console.log(a,b);    
}


}
outer();
